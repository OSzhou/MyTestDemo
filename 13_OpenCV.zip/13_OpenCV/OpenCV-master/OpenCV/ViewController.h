//
//  ViewController.h
//  OpenCV
//
//  Created by 丁琪 on 15/8/23.
//  Copyright (c) 2015年 丁琪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

