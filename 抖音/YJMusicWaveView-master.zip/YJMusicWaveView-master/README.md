# YJMusicWaveView

YJMusicWaveView

![Image text](https://github.com/yangjing901/YJMusicWaveView/blob/master/YJMoreActionSheet.gif)
