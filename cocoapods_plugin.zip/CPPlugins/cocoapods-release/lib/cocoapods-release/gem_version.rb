module CocoapodsRelease
  VERSION = "1.2.11"
end
