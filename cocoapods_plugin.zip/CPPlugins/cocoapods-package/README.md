# cocoapods-package

A description of cocoapods-package.

## Installation

    $ gem install cocoapods-package

## Usage

    $ pod spec package POD_NAME
