//
//  ViewController.m
//  CustomDatePicker
//
//  Created by humor on 15/12/16.
//  Copyright © 2015年 onefiter. All rights reserved.
//

#import "ViewController.h"

#import "AADatePicker.h"

@interface ViewController ()<AADatePickerDelegate>

@property (strong, nonatomic) UILabel *dateLabel;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    AADatePicker *datePicker = [[AADatePicker alloc] initWithFrame:CGRectMake(20, 120, 320, 264) maxDate:[NSDate dateWithTimeIntervalSinceNow:365*24*60*60] minDate:[NSDate date] showValidDatesOnly:YES];
    
    datePicker.delegate = self;
    
    [self.view addSubview:datePicker];
    
    self.dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(datePicker.frame), self.view.frame.size.width, 40)];
    //下方显示时间的label
    
    [self.dateLabel setTextAlignment:NSTextAlignmentCenter];
    
    [self.view addSubview:self.dateLabel];
}

/**
 *  AADatePickerDelegate
 *
 *  @param sender AADatePicker
 */

-(void)dateChanged:(AADatePicker *)sender
{
    NSString *dateString = [NSDateFormatter localizedStringFromDate:sender.date
                                                          dateStyle:NSDateFormatterShortStyle
                                                          timeStyle:NSDateFormatterMediumStyle];
    NSLog(@"%@",dateString);
    
    [self.dateLabel setText:dateString];
}

@end
