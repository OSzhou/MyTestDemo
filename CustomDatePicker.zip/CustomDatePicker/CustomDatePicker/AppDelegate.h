//
//  AppDelegate.h
//  CustomDatePicker
//
//  Created by humor on 15/12/16.
//  Copyright © 2015年 onefiter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

