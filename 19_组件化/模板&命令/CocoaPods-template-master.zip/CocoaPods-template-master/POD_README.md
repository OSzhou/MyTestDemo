# ${POD_NAME}

[![CI Status](https://img.shields.io/travis/${USER_NAME}/${REPO_NAME}.svg?style=flat)](https://travis-ci.org/${USER_NAME}/${REPO_NAME})
[![Version](https://img.shields.io/cocoapods/v/${POD_NAME}.svg?style=flat)](https://cocoapods.org/pods/${POD_NAME})
[![License](https://img.shields.io/cocoapods/l/${POD_NAME}.svg?style=flat)](https://cocoapods.org/pods/${POD_NAME})
[![Platform](https://img.shields.io/cocoapods/p/${POD_NAME}.svg?style=flat)](https://cocoapods.org/pods/${POD_NAME})

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

${POD_NAME} is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod '${POD_NAME}'
```

## Author

${USER_NAME}, ${USER_EMAIL}

## License

${POD_NAME} is available under the MIT license. See the LICENSE file for more info.
