require File.expand_path('../../spec_helper', __FILE__)

module Pod
  describe Command::Package do
    describe 'CLAide' do
      it 'registers it self' do
        Command.parse(%w{ package }).should.be.instance_of Command::Package
      end
    end
  end
end

