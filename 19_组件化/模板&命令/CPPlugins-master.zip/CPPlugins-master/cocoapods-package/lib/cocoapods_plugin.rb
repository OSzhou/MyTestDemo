require 'cocoapods-package/command'
