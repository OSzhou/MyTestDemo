require 'cocoapods-package/command/package'
