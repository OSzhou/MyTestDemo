# cocoapods-release

A description of cocoapods-release.

## Installation

    $ gem install cocoapods-release

## Usage

    $ pod spec release POD_NAME
