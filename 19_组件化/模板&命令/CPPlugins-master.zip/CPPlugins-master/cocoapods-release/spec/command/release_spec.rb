require File.expand_path('../../spec_helper', __FILE__)

module Pod
  describe Command::Release do
    describe 'CLAide' do
      it 'registers it self' do
        Command.parse(%w{ release }).should.be.instance_of Command::Release
      end
    end
  end
end

