module CocoapodsRelease
  VERSION = "1.1.8"
end
