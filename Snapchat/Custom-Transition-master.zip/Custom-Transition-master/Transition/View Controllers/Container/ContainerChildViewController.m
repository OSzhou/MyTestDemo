//
//  ContainerChildViewController.m
//  Transition
//
//  Created by Pablo Romero on 8/27/16.
//  Copyright © 2016 Pablo Romero. All rights reserved.
//

#import "ContainerChildViewController.h"

@implementation ContainerChildViewController

- (void)updateInteractiveTransition:(CGFloat)progress
{
    // Override
}

- (void)cancelInteractiveTransition
{
    // Override
}

- (void)finishInteractiveTransition
{
    // Override
}

@end
