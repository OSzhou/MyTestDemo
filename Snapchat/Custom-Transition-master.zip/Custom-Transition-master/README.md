# Custom Transition

[![License](https://img.shields.io/cocoapods/l/ElasticTransition.svg?style=flat)](http://cocoapods.org/pods/ElasticTransition)
[![Platform](https://img.shields.io/cocoapods/p/ElasticTransition.svg?style=flat)](http://cocoapods.org/pods/ElasticTransition)

This project tries to replicate the transition that you can find on Snapchat when you pull down to access Profile screen.

This is the original Snapchat transition:

![demo](http://microedition.biz/download/GitHub/ezgif.com-video-to-gif-3.gif)

This is how the transition looks in this project:

![demo](http://microedition.biz/download/GitHub/ezgif.com-video-to-gif-2.gif)
