//
//  PublicStory.swift
//  simple-snapchat
//
//  Created by Jeffrey on 16/10/16.
//  Copyright © 2016 University of Melbourne. All rights reserved.
//

import UIKit

class PublicStory {
    var title = String()
    var author = String()
    var content = String()
}
