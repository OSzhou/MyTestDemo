//
//  Photo+CoreDataClass.swift
//  simple-snapchat
//
//  Created by Boqin Hu on 16/10/16.
//  Copyright © 2016 University of Melbourne. All rights reserved.
//

import Foundation
import CoreData


public class Photo: NSManagedObject {

}
