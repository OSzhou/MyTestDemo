//
//  Photo.swift
//  simple-snapchat
//
//  Created by Jeffrey on 12/10/16.
//  Copyright © 2016 University of Melbourne. All rights reserved.
//

import UIKit

class SendingPhoto {
    var image: UIImage?
    var timer: Int?
    var imageURL: String?
}
