//
//  Story.swift
//  simple-snapchat
//
//  Created by Jeffrey on 1/10/16.
//  Copyright © 2016 University of Melbourne. All rights reserved.
//

import UIKit

class Story {
    var image: UIImage?
    var imageURL: String?
    var timer: Int?
}
