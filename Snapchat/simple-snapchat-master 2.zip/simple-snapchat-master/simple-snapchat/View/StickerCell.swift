//
//  StickerCell.swift
//  simple-snapchat
//
//  Created by Boqin Hu on 16/10/16.
//  Copyright © 2016 University of Melbourne. All rights reserved.
//

import UIKit

class StickerCell: UICollectionViewCell {
    
    /**
     The outlet of the label shown in each cell.
     */
    @IBOutlet weak var emojilabel: UILabel!
}
