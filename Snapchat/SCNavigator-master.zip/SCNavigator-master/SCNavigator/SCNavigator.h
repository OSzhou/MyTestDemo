//
//  SCNavigator.h
//  SCNavigator
//
//  Created by Reed Bigelow on 1/27/17.
//  Copyright © 2017 Reed Bigelow. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SCNavigator.
FOUNDATION_EXPORT double SCNavigatorVersionNumber;

//! Project version string for SCNavigator.
FOUNDATION_EXPORT const unsigned char SCNavigatorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SCNavigator/PublicHeader.h>


