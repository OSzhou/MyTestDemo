//
//  HFContainerTabbarView.swift
//  ContainerDemo
//
//  Created by zhangliang on 2019/1/20.
//  Copyright © 2019 tataUFO. All rights reserved.
//

import UIKit

protocol TabbarViewSelectionDelegate: class {
    /// 点击某个tab
    func selectTabAt(position: Position)
}

class HFContainerTabbarView: UIView {

    weak var delegate: TabbarViewSelectionDelegate?

    let moveHLimit: CGFloat = 50
    let moveVLimit: CGFloat = 100

    func animate(from: Position,
                 to: Position,
                 percent: CGFloat) {

        let hDelta = moveHLimit * percent
        let vDelta = moveVLimit * percent

        let moveBlock = {

            let toCenter = {
                self.leftButtonLeadingConstraint.constant = self.originLeftButtonLeadingConstraintConstant + hDelta
                self.rightButtonTrailingConstraint.constant = self.originRightButtonTrailingConstraintConstant - hDelta
                self.centerButtonTopConstraint.constant = self.originCenterButtonTopConstraintConstant + vDelta
                self.bottomButtonTopConstraint.constant = self.originBottomButtonTopConstraintConstant + vDelta
            }

            let toOrigin = {
                self.leftButtonLeadingConstraint.constant =  self.originLeftButtonLeadingConstraintConstant + (self.moveHLimit - hDelta)
                self.rightButtonTrailingConstraint.constant = self.originRightButtonTrailingConstraintConstant - (self.moveHLimit - hDelta)
                self.centerButtonTopConstraint.constant = self.originCenterButtonTopConstraintConstant + (self.moveVLimit - vDelta)
                self.bottomButtonTopConstraint.constant = self.originBottomButtonTopConstraintConstant + (self.moveVLimit - vDelta)
            }

            let direction = (from, to)
            switch direction {
            case (.center, .left):
                toCenter()
                break
            case (.center, .right):
                toCenter()
                break
            case (.center, .bottom):
                toCenter()
                break
            case (.left, .center):
                toOrigin()
                break
            case (.left, .right):
                toCenter()
                break
            case (.right, .center):
                toOrigin()
                break
            case (.right, .left):
                toCenter()
                break
            case (.bottom, .center):
                toOrigin()
                break
            default:
                break
            }
            self.layoutIfNeeded()
        }

        moveBlock()
    }

    func cancelAnimation(from: Position,
                         to: Position?) {
        let hDelta = moveHLimit
        let vDelta = moveVLimit

        let moveBlock = {

            let toCenter = {
                self.leftButtonLeadingConstraint.constant = self.originLeftButtonLeadingConstraintConstant + hDelta
                self.rightButtonTrailingConstraint.constant = self.originRightButtonTrailingConstraintConstant - hDelta
                self.centerButtonTopConstraint.constant = self.originCenterButtonTopConstraintConstant + vDelta
                self.bottomButtonTopConstraint.constant = self.originBottomButtonTopConstraintConstant + vDelta
            }

            let toOrigin = {
                self.leftButtonLeadingConstraint.constant =  self.originLeftButtonLeadingConstraintConstant + (self.moveHLimit - hDelta)
                self.rightButtonTrailingConstraint.constant = self.originRightButtonTrailingConstraintConstant - (self.moveHLimit - hDelta)
                self.centerButtonTopConstraint.constant = self.originCenterButtonTopConstraintConstant + (self.moveVLimit - vDelta)
                self.bottomButtonTopConstraint.constant = self.originBottomButtonTopConstraintConstant + (self.moveVLimit - vDelta)
            }

            let direction = (from, to)
            switch direction {
            case (.center, .left?):
                toOrigin()
                break
            case (.center, .right?):
                toOrigin()
                break
            case (.center, .bottom?):
                toOrigin()
                break
            case (.left, .center?):
                toCenter()
                break
            case (.left, .right?):
                toCenter()
                break
            case (.right, .center?):
                toCenter()
                break
            case (.right, .left?):
                toCenter()
                break
            case (.bottom, .center?):
                toCenter()
                break
            default:
                break
            }
            self.layoutIfNeeded()
        }

        UIView.animate(withDuration: HFContainerAnimationDuration,
                       delay: 0,
                       options: .curveLinear,
                       animations: moveBlock) { (finished) in
        }
    }

    func finishAnimation(from: Position,
                         to: Position?) {

        let hDelta = moveHLimit
        let vDelta = moveVLimit

        let moveBlock = {

            let toCenter = {
                self.leftButtonLeadingConstraint.constant = self.originLeftButtonLeadingConstraintConstant + hDelta
                self.rightButtonTrailingConstraint.constant = self.originRightButtonTrailingConstraintConstant - hDelta
                self.centerButtonTopConstraint.constant = self.originCenterButtonTopConstraintConstant + vDelta
                self.bottomButtonTopConstraint.constant = self.originBottomButtonTopConstraintConstant + vDelta
            }

            let toOrigin = {
                self.leftButtonLeadingConstraint.constant =  self.originLeftButtonLeadingConstraintConstant
                self.rightButtonTrailingConstraint.constant = self.originRightButtonTrailingConstraintConstant
                self.centerButtonTopConstraint.constant = self.originCenterButtonTopConstraintConstant
                self.bottomButtonTopConstraint.constant = self.originBottomButtonTopConstraintConstant
            }

            let direction = (from, to)
            switch direction {
            case (.center, .left?):
                toCenter()
                break
            case (.center, .right?):
                toCenter()
                break
            case (.center, .bottom?):
                toCenter()
                break
            case (.left, .center?):
                toOrigin()
                break
            case (.left, .right?):
                toCenter()
                break
            case (.right, .center?):
                toOrigin()
                break
            case (.right, .left?):
                toCenter()
                break
            case (.bottom, .center?):
                toOrigin()
                break
            default:
                break
            }
            self.layoutIfNeeded()
        }

        UIView.animate(withDuration: HFContainerAnimationDuration,
                       delay: 0,
                       options: .curveLinear,
                       animations: moveBlock) { (finished) in
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)

        self.backgroundColor = UIColor.clear

        self.addSubview(self.leftButton)
        self.leftButton.translatesAutoresizingMaskIntoConstraints = false
        self.leftButtonWidthConstraint = self.leftButton.widthAnchor.constraint(equalToConstant: 50)
        self.leftButtonHeightConstraint = self.leftButton.heightAnchor.constraint(equalToConstant: 50)
        self.leftButtonBottomConstraint = self.leftButton.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0)
        self.leftButtonLeadingConstraint = self.leftButton.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10)
        self.originLeftButtonLeadingConstraintConstant = self.leftButtonLeadingConstraint.constant
        NSLayoutConstraint.activate([
            self.leftButtonWidthConstraint,
            self.leftButtonHeightConstraint,
            self.leftButtonLeadingConstraint,
            self.leftButtonBottomConstraint,
            ])

        self.addSubview(self.rightButton)
        self.rightButton.translatesAutoresizingMaskIntoConstraints = false
        self.rightButtonWidthConstraint = self.rightButton.widthAnchor.constraint(equalToConstant: 50)
        self.rightButtonHeightConstraint = self.rightButton.heightAnchor.constraint(equalToConstant: 50)
        self.rightButtonBottomConstraint = self.rightButton.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0)
        self.rightButtonTrailingConstraint = self.rightButton.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10)
        self.originRightButtonTrailingConstraintConstant = self.rightButtonTrailingConstraint.constant
        NSLayoutConstraint.activate([
            self.rightButtonWidthConstraint,
            self.rightButtonHeightConstraint,
            self.rightButtonTrailingConstraint,
            self.rightButtonBottomConstraint,
            ])

        self.addSubview(self.centerButton)
        self.centerButton.translatesAutoresizingMaskIntoConstraints = false
        self.centerButtonWidthConstraint = self.centerButton.widthAnchor.constraint(equalToConstant: 152)
        self.centerButtonTopConstraint = self.centerButton.topAnchor.constraint(equalTo: self.topAnchor, constant: 0)
        self.originCenterButtonTopConstraintConstant = self.centerButtonTopConstraint.constant
        self.centerButtonHeightConstraint = self.centerButton.heightAnchor.constraint(equalToConstant: 152)
        NSLayoutConstraint.activate([
            self.centerButtonWidthConstraint,
            self.centerButtonHeightConstraint,
            self.centerButtonTopConstraint,
            self.centerButton.centerXAnchor.constraint(equalTo: self.centerXAnchor, constant: 0)
            ])

        self.addSubview(self.bottomButton)
        self.bottomButton.translatesAutoresizingMaskIntoConstraints = false
        self.bottomButtonWidthConstraint = self.bottomButton.widthAnchor.constraint(equalToConstant: 80)
        self.bottomButtonTopConstraint = self.bottomButton.topAnchor.constraint(equalTo: self.bottomAnchor, constant: -100)
        self.originBottomButtonTopConstraintConstant = self.bottomButtonTopConstraint.constant
        self.bottomButtonHeightConstraint = self.bottomButton.heightAnchor.constraint(equalToConstant: 50)
        NSLayoutConstraint.activate([
            self.bottomButtonWidthConstraint,
            self.bottomButtonHeightConstraint,
            self.bottomButtonTopConstraint,
            self.bottomButton.centerXAnchor.constraint(equalTo: self.centerXAnchor, constant: 0)
            ])
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        if !self.isUserInteractionEnabled || self.isHidden || self.alpha <= 0.01 {
            return nil;
        }

        for subview in subviews {
            let childPoint = convert(point, to: subview)
            let fitview = subview.hitTest(childPoint, with: event)
            if let fv = fitview {
                return fv
            }
        }
        return nil
    }

    var leftButtonLeadingConstraint: NSLayoutConstraint!
    var originLeftButtonLeadingConstraintConstant: CGFloat!
    var leftButtonWidthConstraint: NSLayoutConstraint!
    var leftButtonHeightConstraint: NSLayoutConstraint!
    var leftButtonBottomConstraint: NSLayoutConstraint!
    lazy var leftButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(leftButtonClicked(_ :)), for: .touchUpInside)
        button.setTitle("left", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        return button
    }()

    @objc func leftButtonClicked(_ sender: UIButton) {
        self.delegate?.selectTabAt(position: .left)
    }

    var centerButtonTopConstraint: NSLayoutConstraint!
    var originCenterButtonTopConstraintConstant: CGFloat!
    var centerButtonWidthConstraint: NSLayoutConstraint!
    var centerButtonHeightConstraint: NSLayoutConstraint!
    lazy var centerButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(centerButtonClicked(_ :)), for: .touchUpInside)
        button.setTitle("center", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        return button
    }()

    @objc func centerButtonClicked(_ sender: UIButton) {
        self.delegate?.selectTabAt(position: .center)
    }

    var rightButtonTrailingConstraint: NSLayoutConstraint!
    var rightButtonWidthConstraint: NSLayoutConstraint!
    var rightButtonHeightConstraint: NSLayoutConstraint!
    var rightButtonBottomConstraint: NSLayoutConstraint!
    var originRightButtonTrailingConstraintConstant: CGFloat!
    lazy var rightButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(rightButtonClicked(_ :)), for: .touchUpInside)
        button.setTitle("right", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        return button
    }()

    @objc func rightButtonClicked(_ sender: UIButton) {
        self.delegate?.selectTabAt(position: .right)
    }

    var bottomButtonWidthConstraint: NSLayoutConstraint!
    var bottomButtonHeightConstraint: NSLayoutConstraint!
    var bottomButtonTopConstraint: NSLayoutConstraint!
    var originBottomButtonTopConstraintConstant: CGFloat!
    lazy var bottomButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(bottomButtonClicked(_ :)), for: .touchUpInside)
        button.setTitle("bottom", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        return button
    }()

    @objc func bottomButtonClicked(_ sender: UIButton) {
        self.delegate?.selectTabAt(position: .bottom)
    }

}
