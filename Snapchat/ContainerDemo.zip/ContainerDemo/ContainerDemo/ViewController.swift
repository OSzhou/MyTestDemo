//
//  ViewController.swift
//  ContainerDemo
//
//  Created by zhangliang on 2019/1/18.
//  Copyright © 2019 tataUFO. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.orange

        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(buttonClicked(_:)), for: .touchUpInside)
        button.frame = CGRect(x: 100, y: 100, width: 80, height: 44)
        button.setTitle("hello", for: .normal)
        view.addSubview(button)
    }

    @objc func buttonClicked(_ sender: UIButton) {

        let center = CenterViewController()
        let left = LeftViewController()
        let bottom = BottomViewController()
        let right = RightViewController()

        let vc = HFContainerController(center: center, left: left, bottom: bottom, right: right)

        present(vc, animated: true, completion: nil)
    }

}

