//
//  HFContainerNavgationBarView.swift
//  ContainerDemo
//
//  Created by zhangliang on 2019/1/20.
//  Copyright © 2019 tataUFO. All rights reserved.
//

import UIKit

protocol HFContainerNavgationBarViewDelegate: class {
    func navClick(leftButton: UIButton)
}

class HFContainerNavgationBarView: UIView {

    weak var delegate: HFContainerNavgationBarViewDelegate?

    func animate(from: Position,
                 to: Position,
                 percent: CGFloat) {

    }

    func cancelAnimation(from: Position,
                         to: Position?) {

    }

    func finishAnimation(from: Position,
                         to: Position?) {

    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)

        self.backgroundColor = UIColor.blue

        self.addSubview(self.leftButton)
        self.leftButton.translatesAutoresizingMaskIntoConstraints = false
        self.leftButtonWidthConstraint = self.leftButton.widthAnchor.constraint(equalToConstant: 50)
        self.leftButtonHeightConstraint = self.leftButton.heightAnchor.constraint(equalToConstant: 50)
        self.leftButtonBottomConstraint = self.leftButton.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0)
        self.leftButtonLeadingConstraint = self.leftButton.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10)
        self.originLeftButtonLeadingConstraintConstant = self.leftButtonLeadingConstraint.constant
        NSLayoutConstraint.activate([
            self.leftButtonWidthConstraint,
            self.leftButtonHeightConstraint,
            self.leftButtonLeadingConstraint,
            self.leftButtonBottomConstraint,
            ])
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    var leftButtonLeadingConstraint: NSLayoutConstraint!
    var originLeftButtonLeadingConstraintConstant: CGFloat!
    var leftButtonWidthConstraint: NSLayoutConstraint!
    var leftButtonHeightConstraint: NSLayoutConstraint!
    var leftButtonBottomConstraint: NSLayoutConstraint!
    lazy var leftButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(leftButtonClicked(_ :)), for: .touchUpInside)
        button.setTitle("left", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        return button
    }()

    @objc func leftButtonClicked(_ sender: UIButton) {
        self.delegate?.navClick(leftButton: sender)
    }
}
