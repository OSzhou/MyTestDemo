//
//  HFContainerChildViewController.swift
//  ContainerDemo
//
//  Created by zhangliang on 2019/1/20.
//  Copyright © 2019 tataUFO. All rights reserved.
//

import UIKit

class HFContainerChildViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    deinit {
        print("deinit: \(self)")
    }

}
