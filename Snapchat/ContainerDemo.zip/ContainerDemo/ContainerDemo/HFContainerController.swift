//
//  HFContainerController.swift
//  ContainerDemo
//
//  Created by zhangliang on 2019/1/20.
//  Copyright © 2019 tataUFO. All rights reserved.
//

import UIKit

enum Position {
    case center
//    case top
    case bottom
    case left
    case right
}

enum ActivePanDirection {
    case undefined
    case horizontal
    case vertical
}

let HFContainerAnimationDuration = 0.25

class HFContainerController: UIViewController {

    var centerVC: HFContainerChildViewController!

//    var topViewController: HFContainerChildViewController!

    // Left
    var leftVCRightConstraint: NSLayoutConstraint!
    var leftVC: HFContainerChildViewController!

    // Bottom
    var bottomVCTopConstraint: NSLayoutConstraint!
    var bottomVC: HFContainerChildViewController!

    // Right
    var rightVCLeftConstraint: NSLayoutConstraint!
    var rightVC: HFContainerChildViewController!

    // Gesture
    private var panGesture: UIPanGestureRecognizer!

    /// 手势方向，一次手势行为只允许一个方向
    private var activePanDirection = ActivePanDirection.undefined
    /// 当前位置
    private var currentPosition: Position = .center
    /// 即将激活位置，手势滑动过程中会更改，手势不动时为空
    private var willPosition: Position?

    /// 当前所在的控制器
    var currentActiveViewController: HFContainerChildViewController! {
        switch currentPosition {
        case .bottom:
            return bottomVC
        case .left:
            return leftVC
        case .right:
            return rightVC
        default:
            return centerVC
        }
    }

    var navview: HFContainerNavgationBarView!

    var tabbarBottomConstraint: NSLayoutConstraint!
    var tabbarView: HFContainerTabbarView!

    /// 是否应该完成页面切换
    var shouldCompleteTransition: Bool = false
    /// 是否正在交互
    var interactionInProgress: Bool = false

    deinit {
        print("deinit: \(self)")
        
        func remove(vc: UIViewController) {
            vc.willMove(toParent: nil)
            vc.view.removeFromSuperview()
            vc.removeFromParent()
        }

        remove(vc: centerVC)
        remove(vc: leftVC)
        remove(vc: rightVC)
        remove(vc: bottomVC)
    }

    init(center: HFContainerChildViewController,
         left: HFContainerChildViewController,
         bottom: HFContainerChildViewController,
         right: HFContainerChildViewController) {

        super.init(nibName: nil, bundle: nil)

        let width = UIScreen.main.bounds.width
        let height = UIScreen.main.bounds.height

        // Center
        self.centerVC = center
        center.view.translatesAutoresizingMaskIntoConstraints = false
        embed(vc: center)
        NSLayoutConstraint.activate([
            center.view.topAnchor.constraint(equalTo: view.topAnchor, constant: 0),
            center.view.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            center.view.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0),
            center.view.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0),
            ])

        // Left
        self.leftVC = left
        left.view.translatesAutoresizingMaskIntoConstraints = false
        embed(vc: left)
        self.leftVCRightConstraint = left.view.rightAnchor.constraint(equalTo: view.leftAnchor, constant: 0)
        NSLayoutConstraint.activate([
            left.view.widthAnchor.constraint(equalToConstant: width),
            left.view.heightAnchor.constraint(equalToConstant: height),
            left.view.topAnchor.constraint(equalTo: view.topAnchor, constant: 0),
            leftVCRightConstraint
            ])

        // Right
        self.rightVC = right
        right.view.translatesAutoresizingMaskIntoConstraints = false
        embed(vc: right)
        self.rightVCLeftConstraint = right.view.leftAnchor.constraint(equalTo: view.rightAnchor, constant: 0)
        NSLayoutConstraint.activate([
            right.view.widthAnchor.constraint(equalToConstant: width),
            right.view.heightAnchor.constraint(equalToConstant: height),
            right.view.topAnchor.constraint(equalTo: view.topAnchor, constant: 0),
            rightVCLeftConstraint
            ])

        // Bottom
        self.bottomVC = bottom
        bottom.view.translatesAutoresizingMaskIntoConstraints = false
        embed(vc: bottom)
        self.bottomVCTopConstraint = bottom.view.topAnchor.constraint(equalTo: view.bottomAnchor, constant: 0)
        NSLayoutConstraint.activate([
            bottom.view.widthAnchor.constraint(equalToConstant: width),
            bottom.view.heightAnchor.constraint(equalToConstant: height),
            bottomVCTopConstraint,
            bottom.view.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0)
            ])

        // Gesture
        panGesture = UIPanGestureRecognizer(target: self, action: #selector(panGesture(_:)))
        view.addGestureRecognizer(panGesture)


        self.tabbarView = HFContainerTabbarView()
        self.tabbarView.delegate = self
        view.addSubview(self.tabbarView)
        self.tabbarView.translatesAutoresizingMaskIntoConstraints = false
        self.tabbarBottomConstraint = self.tabbarView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0)
        NSLayoutConstraint.activate([
            self.tabbarView.widthAnchor.constraint(equalToConstant: width),
            self.tabbarView.heightAnchor.constraint(equalToConstant: 277),
            self.tabbarView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            self.tabbarBottomConstraint
            ])

        self.navview = HFContainerNavgationBarView()
        self.navview.delegate = self
        view.addSubview(self.navview)
        self.navview.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            self.navview.widthAnchor.constraint(equalToConstant: width),
            self.navview.heightAnchor.constraint(equalToConstant: 64),
            self.navview.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            self.navview.topAnchor.constraint(equalTo: view.topAnchor, constant: 0)
            ])
    }

    func embed(vc: UIViewController) {
        addChild(vc)
        vc.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(vc.view)
        vc.didMove(toParent: self)
    }

    @objc private func panGesture(_ sender: UIPanGestureRecognizer) {

        let translation = sender.translation(in: view)

        let xprogress = translation.x / view.frame.size.width
        let xabsprogress = abs(xprogress)

        let yprogress = translation.y / view.frame.size.height
        let yabsprogress = abs(yprogress)

        switch sender.state {
        case .began:
            activePanDirection = .undefined

            shouldCompleteTransition = false
            interactionInProgress = true

        case .changed:

            /// 水平方向移动最小限制
            let xtranslationLimit: CGFloat = 0.5
            /// 垂直方向移动最小限制
            let ytranslationLimit: CGFloat = 0.3

            switch activePanDirection {
            case .undefined:
                activePanDirection = abs(translation.x) > abs(translation.y) ? .horizontal : .vertical
                break
            case .horizontal:
                if self.interactionInProgress {
                    self.shouldCompleteTransition = xabsprogress > xtranslationLimit
                    switch currentPosition {
                    case .center:
                        if xprogress > 0 {
                            self.moveTransion(from: .center, to: .left, progress: xabsprogress)
                        } else {
                            self.moveTransion(from: .center, to: .right, progress: xabsprogress)
                        }
                        break
                    case .left:
                        if xprogress > 0 {
                            return
                        } else {
                            self.moveTransion(from: .left, to: .center, progress: xabsprogress)
                        }
                        break
                    case .right:
                        if xprogress < 0 {
                            return
                        } else {
                            self.moveTransion(from: .right, to: .center, progress: xabsprogress)
                        }
                        break
                    default:
                        return
                    }
                }

            case .vertical:
                if self.interactionInProgress {
                    self.shouldCompleteTransition = yabsprogress > ytranslationLimit

                    switch currentPosition {
                    case .center:
                        if yprogress < 0 {
                            self.moveTransion(from: .center, to: .bottom, progress: yabsprogress)
                        } else {
                            return
                        }
                        break
                    case .bottom:
                        if yprogress > 0 {
                            self.moveTransion(from: .bottom, to: .center, progress: yabsprogress)
                        } else {
                            return
                        }
                        break
                    default:
                        return
                    }
                }
            }
            break

        case .ended:
            /// 当用户迅速滑动屏幕来切换时，
            let velocity = sender.velocity(in: view)
            let velocityLimit: CGFloat = 800.0

            switch activePanDirection {
            case .horizontal:
                self.shouldCompleteTransition = abs(velocity.x) > velocityLimit
                break
            case .vertical:
                self.shouldCompleteTransition = abs(velocity.y) > velocityLimit
                break
            default:
                break
            }

            if self.interactionInProgress {
                self.interactionInProgress = false

                if self.shouldCompleteTransition {
                    self.finishTransition()
                } else {
                    self.cancelTransition()
                }
            }
            break

        case .failed:
            fallthrough
        case .cancelled:
            if self.interactionInProgress {
                self.interactionInProgress = false

                self.cancelTransition()
            }
            break
        default:
            break
        }
    }

    func finishTransition() {
        self.finishInteractiveTransition()
        self.tabbarView.finishAnimation(from: self.currentPosition, to: self.willPosition)
    }

    func cancelTransition() {
        self.cancelInteractiveTransition()
        self.tabbarView.cancelAnimation(from: self.currentPosition, to: self.willPosition)
    }

    func moveTransion(from: Position, to: Position, progress: CGFloat) {
        self.move(from: from, to: to, progress: progress)
        self.tabbarView.animate(from: from, to: to, percent: progress)
    }

    func move(from: Position, to: Position, progress: CGFloat) {
//        print("move from: \(from) to: \(to)  progress: \(progress)")

        let screenWidth = UIScreen.main.bounds.width
        let screenHeight = UIScreen.main.bounds.height

        let xDelta = screenWidth * progress
        let yDelta = screenHeight * progress
//        print("xDelta = \(xDelta), yDelta = \(yDelta)")

        let moveBlock = {
            let direction = (from, to)
            switch direction {
            case (.center, .left):
                self.leftVCRightConstraint.constant = xDelta
                self.rightVCLeftConstraint.constant = 0
                break
            case (.center, .right):
                self.rightVCLeftConstraint.constant = -xDelta
                self.leftVCRightConstraint.constant = 0
                break
            case (.center, .bottom):
                self.bottomVCTopConstraint.constant = -yDelta
                break
            case (.left, .center):
                self.leftVCRightConstraint.constant = screenWidth - xDelta
                self.rightVCLeftConstraint.constant = 0
                break
            case (.left, .right):
                self.leftVCRightConstraint.constant = screenWidth - xDelta
                self.rightVCLeftConstraint.constant = -(screenWidth - xDelta)
                break
            case (.right, .center):
                self.rightVCLeftConstraint.constant = -screenWidth + xDelta
                self.leftVCRightConstraint.constant = 0
                break
            case (.right, .left):
                self.leftVCRightConstraint.constant = -xDelta
                self.rightVCLeftConstraint.constant = xDelta
                break
            case (.bottom, .center):
                self.bottomVCTopConstraint.constant = -(screenHeight - yDelta)
                break
            default:
                break
            }
            self.view.layoutIfNeeded()
        }

        moveBlock()

        willPosition = to
    }

    func cancelInteractiveTransition() {
        let screenWidth = UIScreen.main.bounds.width
        let screenHeight = UIScreen.main.bounds.height

        let moveBlock = {
            let direction = (self.currentPosition, self.willPosition)
            switch direction {
            case (.center, .left?):
                self.leftVCRightConstraint.constant = 0
                self.rightVCLeftConstraint.constant = 0
                break
            case (.center, .right?):
                self.rightVCLeftConstraint.constant = 0
                self.leftVCRightConstraint.constant = 0
                break
            case (.center, .bottom?):
                self.bottomVCTopConstraint.constant = 0
                break
            case (.left, .center?):
                self.leftVCRightConstraint.constant = screenWidth
                self.rightVCLeftConstraint.constant = 0
                break
            case (.left, .right?):
                self.leftVCRightConstraint.constant = screenWidth
                self.rightVCLeftConstraint.constant = 0
                break
            case (.right, .center?):
                self.leftVCRightConstraint.constant = 0
                self.rightVCLeftConstraint.constant = -screenWidth
                break
            case (.right, .left?):
                self.leftVCRightConstraint.constant = 0
                self.rightVCLeftConstraint.constant = -screenWidth
                break
            case (.bottom, .center?):
                self.bottomVCTopConstraint.constant = -screenHeight
                break
            default:
                break
            }
            self.view.layoutIfNeeded()
        }

        UIView.animate(withDuration: HFContainerAnimationDuration,
                       delay: 0,
                       options: .curveLinear,
                       animations: moveBlock) { (finished) in
                        self.willPosition = nil
        }
    }

    func finishInteractiveTransition() {
        let screenWidth = UIScreen.main.bounds.width
        let screenHeight = UIScreen.main.bounds.height

        let moveBlock = {
            let direction = (self.currentPosition, self.willPosition)
            switch direction {
            case (.center, .left?):
                self.leftVCRightConstraint.constant = screenWidth
                self.rightVCLeftConstraint.constant = 0
                break
            case (.center, .right?):
                self.rightVCLeftConstraint.constant = -screenWidth
                self.leftVCRightConstraint.constant = 0
                break
            case (.center, .bottom?):
                self.bottomVCTopConstraint.constant = -screenHeight
                break
            case (.left, .center?):
                self.leftVCRightConstraint.constant = 0
                self.rightVCLeftConstraint.constant = 0
                break
            case (.left, .right?):
                self.leftVCRightConstraint.constant = 0
                self.rightVCLeftConstraint.constant = -screenWidth
                break
            case (.right, .center?):
                self.rightVCLeftConstraint.constant = 0
                self.leftVCRightConstraint.constant = 0
                break
            case (.right, .left?):
                self.leftVCRightConstraint.constant = screenWidth
                self.rightVCLeftConstraint.constant = 0
                break
            case (.bottom, .center?):
                self.bottomVCTopConstraint.constant = 0
                break
            default:
                break
            }
            self.view.layoutIfNeeded()
        }

        UIView.animate(withDuration: HFContainerAnimationDuration,
                       delay: 0,
                       options: .curveLinear,
                       animations: moveBlock) { (finished) in
                        defer {
                            self.willPosition = nil
                        }

                        guard let wp = self.willPosition else {
                            return
                        }

                        self.currentPosition = wp
        }
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}

extension HFContainerController: TabbarViewSelectionDelegate {
    func selectTabAt(position: Position) {
        self.willPosition = position

        if self.currentPosition == .bottom && (self.willPosition! == .left || self.willPosition! == .right) {
            return
        }

        if self.willPosition! == .bottom && (self.currentPosition == .left || self.currentPosition == .right)  {
            return
        }

        self.finishTransition()
    }
}

extension HFContainerController: HFContainerNavgationBarViewDelegate {
    func navClick(leftButton: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
}
