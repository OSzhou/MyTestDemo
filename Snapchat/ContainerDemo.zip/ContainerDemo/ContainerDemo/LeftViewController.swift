//
//  LeftViewController.swift
//  ContainerDemo
//
//  Created by zhangliang on 2019/1/20.
//  Copyright © 2019 tataUFO. All rights reserved.
//

import UIKit

class LeftViewController: HFContainerChildViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.lightText

        view.addSubview(self.leftButton)
        self.leftButton.frame = CGRect(x: 100, y: 100, width: 100, height: 100)
    }

    lazy var leftButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(leftButtonClicked(_ :)), for: .touchUpInside)
        button.setTitle("left", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        return button
    }()

    @objc func leftButtonClicked(_ sender: UIButton) {

    }

}
