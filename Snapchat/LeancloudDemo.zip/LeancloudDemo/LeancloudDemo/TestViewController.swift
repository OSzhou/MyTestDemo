//
//  TestViewController.swift
//  LeancloudDemo
//
//  Created by zhangliang on 2019/1/18.
//  Copyright © 2019 TTC. All rights reserved.
//

import UIKit

class TestViewController: SCNavigatorController {

    override func setupView() {
        datasource = self
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension TestViewController : SCNavigationDataSource
{
    public func ViewControllers() -> [UIViewController] {

        let LeftVC      = UIViewController()
        let RightVC     = UIViewController()
        let BottomVC    = UIViewController()
        let TopVC       = UIViewController()
        let CenterVC    = UIViewController()

        return [LeftVC,RightVC,BottomVC,TopVC,CenterVC]
    }
}
