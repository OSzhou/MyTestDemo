//
//  ViewController.swift
//  LeancloudDemo
//
//  Created by zhangliang on 2019/1/7.
//  Copyright © 2019 TTC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

